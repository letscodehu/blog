@extends("lara-admin::layout")

@section("content")
    Múkodik view-al is!
@endsection
