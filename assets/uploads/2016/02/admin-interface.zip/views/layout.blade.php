<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Teszt</title>
    <link rel="stylesheet" href="assets/css/style.css" media="screen" />
    <script type="text/javascript" src="assets/js/site.js"></script>
</head>
<body>
@yield('content')
</body>
</html>