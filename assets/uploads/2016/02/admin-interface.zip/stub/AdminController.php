<?php


namespace App\Http\Controllers\Admin\AdminController;

use Letscode\Admin\Controllers\AdminController as ParentController;

class AdminController extends ParentController
{

}