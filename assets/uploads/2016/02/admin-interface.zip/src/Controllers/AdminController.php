<?php

namespace Letscode\Admin\Controllers;

use Illuminate\Routing\Controller;

class AdminController extends Controller
{
    public function index() {
        return view("lara-admin::index");
    }

}