<?php 

namespace Letscode\Admin;


use Illuminate\Support\ServiceProvider;

class AdminInterfaceProvider extends ServiceProvider {

    public function boot() {

        $this->publishes([
            __DIR__.'/../stub/AdminController.php' => base_path('app/Http/Controllers/Admin/AdminController.php'),
        ]);

        $this->publishes([
            __DIR__.'/../stub/routes.php' => base_path('app/Http/admin-routes.php'),
        ]); // a route-jainkat ide publisholjuk

        if (file_exists(base_path("app/Http/admin-routes.php"))) {
            require base_path("app/Http/admin-routes.php");
        }

        $this->loadViewsFrom(__DIR__.'/../views', 'lara-admin');

        $this->publishes([
            __DIR__.'/../views' => base_path('resources/views/vendor/lara-admin'),
        ]);


        $this->publishes([
            __DIR__.'/../assets' => base_path('public/assets'),
        ]);

    }

    public function register() {

    }
}